const express = require('express');
const { Parser } = require('json2csv');
const PDFDocument = require('pdfkit');
const auth = require('../middleware/auth');
const Rescue = require('../models/Rescue');
const User = require('../models/User');
const NGO = require('../models/NGO');

const router = express.Router();

// @route   GET /api/exports/rescue/:id
// @desc    Export single rescue report (PDF/CSV) - FIXED NGO PERMISSIONS
// @access  Private
router.get('/rescue/:id', auth, async (req, res) => {
  try {
    const { format = 'pdf' } = req.query;
    const rescueId = req.params.id;

    console.log(`📊 Export request: ${format.toUpperCase()} for rescue ${rescueId} by ${req.user.email} (${req.user.role})`);

    // Get rescue with full population
    const rescue = await Rescue.findById(rescueId)
      .populate('reporter', 'name email phone')
      .populate('assignedNGO', 'organizationName contactEmail')
      .lean();

    if (!rescue) {
      console.log(`❌ Rescue not found: ${rescueId}`);
      return res.status(404).json({
        success: false,
        message: 'Rescue not found'
      });
    }

    console.log(`📋 Found rescue: ${rescue.title}`);
    console.log(`👤 Reporter: ${rescue.reporter?._id}`);
    console.log(`🏢 Assigned NGO: ${rescue.assignedNGO?._id}`);

    // FIXED: Permission check
    let hasAccess = false;
    
    if (req.user.role === 'admin') {
      hasAccess = true;
      console.log('✅ Admin access granted');
    } else if (req.user.role === 'user') {
      // Users can export their own reports
      hasAccess = rescue.reporter && rescue.reporter._id.toString() === req.user.id;
      console.log(`🔍 User access check: ${hasAccess} (${rescue.reporter?._id} === ${req.user.id})`);
    } else if (req.user.role === 'ngo') {
      // NGOs can export rescues assigned to them OR unassigned public rescues
      try {
        const ngoProfile = await NGO.findOne({ user: req.user.id });
        console.log(`🏢 NGO Profile found: ${ngoProfile?._id}`);
        
        if (ngoProfile) {
          // Check if rescue is assigned to this NGO
          const isAssignedToNGO = rescue.assignedNGO && rescue.assignedNGO._id.toString() === ngoProfile._id.toString();
          // Check if rescue is unassigned and public
          const isUnassignedPublic = !rescue.assignedNGO && rescue.isPublic !== false;
          
          hasAccess = isAssignedToNGO || isUnassignedPublic;
          
          console.log(`🔍 NGO access check:
            - NGO Profile ID: ${ngoProfile._id}
            - Assigned NGO ID: ${rescue.assignedNGO?._id}
            - Is assigned to NGO: ${isAssignedToNGO}
            - Is unassigned public: ${isUnassignedPublic}
            - Final access: ${hasAccess}`);
        } else {
          console.log('❌ NGO profile not found');
          hasAccess = false;
        }
      } catch (ngoError) {
        console.error('❌ NGO lookup error:', ngoError);
        hasAccess = false;
      }
    }

    if (!hasAccess) {
      console.log(`❌ Access denied for ${req.user.role} user ${req.user.email}`);
      return res.status(403).json({
        success: false,
        message: 'Access denied. You do not have permission to export this rescue report.'
      });
    }

    console.log(`✅ Access granted for ${req.user.role} user ${req.user.email}`);

    if (format === 'csv') {
      // CSV Export
      const csvData = [{
        'Rescue ID': rescue._id,
        'Title': rescue.title,
        'Description': rescue.description,
        'Animal Type': rescue.animal?.type || 'Unknown',
        'Animal Size': rescue.animal?.size || 'Unknown',
        'Animal Gender': rescue.animal?.gender || 'Unknown',
        'Medical Condition': rescue.animal?.medicalCondition || 'None',
        'AI Classification': rescue.animal?.aiPrediction?.species || 'Not classified',
        'AI Confidence': rescue.animal?.aiPrediction?.confidence ? `${Math.round(rescue.animal.aiPrediction.confidence * 100)}%` : 'N/A',
        'Location Address': rescue.location?.address || '',
        'Location City': rescue.location?.city || '',
        'Location State': rescue.location?.state || '',
        'Full Location': `${rescue.location?.address || ''}${rescue.location?.address ? ', ' : ''}${rescue.location?.city || ''}${rescue.location?.city && rescue.location?.state ? ', ' : ''}${rescue.location?.state || ''}`.trim() || 'Not specified',
        'Urgency': rescue.urgency,
        'Status': rescue.status,
        'Reporter': rescue.reporter?.name || 'Unknown',
        'Reporter Email': rescue.reporter?.email || 'Unknown',
        'Assigned NGO': rescue.assignedNGO?.organizationName || 'Not assigned',
        'Created Date': new Date(rescue.createdAt).toLocaleDateString(),
        'Last Updated': new Date(rescue.updatedAt).toLocaleDateString()
      }];

      const { Parser } = require('json2csv');
      const parser = new Parser();
      const csv = parser.parse(csvData);

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="rescue-report-${rescueId}.csv"`);
      
      console.log('📊 Sending CSV export');
      return res.send(csv);
      
    } else {
      // PDF Export
      const PDFDocument = require('pdfkit');
      const doc = new PDFDocument({ margin: 50 });
      
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="rescue-report-${rescueId}.pdf"`);
      doc.pipe(res);

      // Header
      doc.fontSize(20).text('Animal Rescue Report', 50, 50);
      doc.fontSize(12).text(`Report ID: ${rescue._id}`, 50, 80);
      doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 50, 95);
      doc.text(`Generated by: ${req.user.name || req.user.email} (${req.user.role.toUpperCase()})`, 50, 110);
      doc.moveTo(50, 125).lineTo(550, 125).stroke();

      let y = 145;

      // Basic Information
      doc.fontSize(16).text('Basic Information', 50, y);
      y += 25;
      doc.fontSize(11)
        .text(`Title: ${rescue.title}`, 50, y)
        .text(`Status: ${rescue.status.toUpperCase()}`, 350, y);
      y += 20;
      doc.text(`Urgency: ${rescue.urgency.toUpperCase()}`, 50, y)
        .text(`Created: ${new Date(rescue.createdAt).toLocaleDateString()}`, 350, y);
      y += 25;

      doc.fontSize(11).text(`Description:`, 50, y);
      y += 15;
      doc.text(rescue.description, 50, y, { width: 500, align: 'justify' });
      y += Math.ceil(rescue.description.length / 70) * 12 + 20;

      // Animal Information
      doc.fontSize(16).text('Animal Information', 50, y);
      y += 25;
      doc.fontSize(11)
        .text(`Type: ${rescue.animal?.type || 'Unknown'}`, 50, y)
        .text(`Size: ${rescue.animal?.size || 'Unknown'}`, 200, y)
        .text(`Gender: ${rescue.animal?.gender || 'Unknown'}`, 350, y);
      y += 20;
      doc.text(`Color: ${rescue.animal?.color || 'Not specified'}`, 50, y);
      y += 20;

      if (rescue.animal?.aiPrediction) {
        doc.text(`AI Classification: ${rescue.animal.aiPrediction.species} (${Math.round(rescue.animal.aiPrediction.confidence * 100)}% confidence)`, 50, y);
        y += 20;
      }

      if (rescue.animal?.medicalCondition) {
        doc.text(`Medical Condition: ${rescue.animal.medicalCondition}`, 50, y, { width: 500 });
        y += Math.ceil(rescue.animal.medicalCondition.length / 70) * 12 + 20;
      }

      // Location Information
      doc.fontSize(16).text('Location Information', 50, y);
      y += 25;
      doc.fontSize(11).text(`Address: ${rescue.location?.address || 'Not specified'}`, 50, y);
      y += 15;
      doc.text(`City: ${rescue.location?.city || 'Unknown'}`, 50, y)
        .text(`State: ${rescue.location?.state || 'Unknown'}`, 250, y);
      y += 20;

      if (rescue.location?.coordinates?.latitude) {
        doc.text(`Coordinates: ${rescue.location.coordinates.latitude}, ${rescue.location.coordinates.longitude}`, 50, y);
        y += 20;
      }

      // Reporter Information
      doc.fontSize(16).text('Reporter Information', 50, y);
      y += 25;
      doc.fontSize(11)
        .text(`Name: ${rescue.reporter?.name || 'Unknown'}`, 50, y)
        .text(`Email: ${rescue.reporter?.email || 'Unknown'}`, 300, y);
      y += 25;

      // NGO Information
      if (rescue.assignedNGO) {
        doc.fontSize(16).text('Assigned NGO', 50, y);
        y += 25;
        doc.fontSize(11).text(`Organization: ${rescue.assignedNGO.organizationName}`, 50, y);
        y += 20;
      }

      console.log('📊 Sending PDF export');
      doc.end();
    }

  } catch (error) {
    console.error('❌ Export rescue error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to export rescue report',
      error: error.message
    });
  }
});


// @route   GET /api/exports/dashboard
// @desc    Export user/NGO dashboard data
// @access  Private
router.get('/dashboard', auth, async (req, res) => {
  try {
    const { format = 'csv' } = req.query;
    let filter = {};

    // Role-based filtering
    if (req.user.role === 'user') {
      filter.reporter = req.user.id;
    } else if (req.user.role === 'ngo') {
      const ngoProfile = await NGO.findOne({ user: req.user.id });
      if (ngoProfile) {
        filter.assignedNGO = ngoProfile._id;
      }
    }

    const rescues = await Rescue.find(filter)
      .populate('reporter', 'name email')
      .populate('assignedNGO', 'organizationName')
      .sort({ createdAt: -1 })
      .lean();

    if (format === 'csv') {
      const csvData = rescues.map(rescue => ({
        'Rescue ID': rescue._id,
        'Title': rescue.title,
        'Animal Type': rescue.animal?.type || 'Unknown',
        'Status': rescue.status,
        'Urgency': rescue.urgency,
        'Location': `${rescue.location?.city || ''}, ${rescue.location?.state || ''}`.trim(),
        'AI Classification': rescue.animal?.aiPrediction?.species || 'Not classified',
        'Created Date': new Date(rescue.createdAt).toLocaleDateString(),
        'Reporter': rescue.reporter?.name || 'Unknown',
        'Assigned NGO': rescue.assignedNGO?.organizationName || 'Not assigned'
      }));

      const parser = new Parser();
      const csv = parser.parse(csvData);

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="${req.user.role}-dashboard-${Date.now()}.csv"`);
      res.send(csv);
    } else {
      res.json({
        success: true,
        data: rescues,
        count: rescues.length
      });
    }

  } catch (error) {
    console.error('Export dashboard error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to export dashboard data'
    });
  }
});

// @route   GET /api/exports/admin/overview
// @desc    Export comprehensive admin report
// @access  Admin only
router.get('/admin/overview', auth, async (req, res) => {
  try {
    if (req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Admin access required'
      });
    }

    const { format = 'pdf' } = req.query;

    // Gather comprehensive data
    const [
      totalRescues,
      totalUsers,
      totalNGOs,
      rescuesByStatus,
      rescuesByUrgency,
      rescuesByAnimalType,
      recentRescues,
      aiClassificationStats
    ] = await Promise.all([
      Rescue.countDocuments(),
      User.countDocuments({ role: 'user' }),
      NGO.countDocuments(),
      Rescue.aggregate([
        { $group: { _id: '$status', count: { $sum: 1 } } }
      ]),
      Rescue.aggregate([
        { $group: { _id: '$urgency', count: { $sum: 1 } } }
      ]),
      Rescue.aggregate([
        { $group: { _id: '$animal.type', count: { $sum: 1 } } }
      ]),
      Rescue.find()
        .populate('reporter', 'name email')
        .populate('assignedNGO', 'organizationName')
        .sort({ createdAt: -1 })
        .limit(10)
        .lean(),
      Rescue.aggregate([
        { $match: { 'animal.aiPrediction.species': { $exists: true } } },
        { $group: { _id: '$animal.aiPrediction.species', count: { $sum: 1 } } }
      ])
    ]);

    if (format === 'csv') {
      // Create summary CSV
      const summaryData = [
        { Metric: 'Total Rescues', Value: totalRescues },
        { Metric: 'Total Users', Value: totalUsers },
        { Metric: 'Total NGOs', Value: totalNGOs },
        ...rescuesByStatus.map(item => ({ Metric: `${item._id} Status`, Value: item.count })),
        ...rescuesByUrgency.map(item => ({ Metric: `${item._id} Urgency`, Value: item.count })),
        ...rescuesByAnimalType.map(item => ({ Metric: `${item._id} Animals`, Value: item.count }))
      ];

      const parser = new Parser();
      const csv = parser.parse(summaryData);

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="admin-overview-${Date.now()}.csv"`);
      res.send(csv);
    } else {
      // Generate comprehensive PDF report
      const doc = new PDFDocument({ margin: 50 });
      
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="admin-overview-${Date.now()}.pdf"`);
      doc.pipe(res);

      // Header
      doc.fontSize(24).text('Animal Rescue System - Admin Overview', 50, 50);
      doc.fontSize(12).text(`Generated on: ${new Date().toLocaleDateString()}`, 50, 80);
      doc.moveTo(50, 100).lineTo(550, 100).stroke();

      let y = 120;

      // Summary Statistics
      doc.fontSize(18).text('Summary Statistics', 50, y);
      y += 30;
      
      doc.fontSize(12)
        .text(`Total Rescue Cases: ${totalRescues}`, 50, y)
        .text(`Total Users: ${totalUsers}`, 200, y)
        .text(`Total NGOs: ${totalNGOs}`, 350, y);
      y += 40;

      // Status Breakdown
      doc.fontSize(16).text('Cases by Status', 50, y);
      y += 25;
      rescuesByStatus.forEach(item => {
        doc.fontSize(11).text(`${item._id}: ${item.count} cases`, 70, y);
        y += 18;
      });
      y += 20;

      // Urgency Breakdown
      doc.fontSize(16).text('Cases by Urgency', 50, y);
      y += 25;
      rescuesByUrgency.forEach(item => {
        doc.fontSize(11).text(`${item._id}: ${item.count} cases`, 70, y);
        y += 18;
      });
      y += 20;

      // Animal Type Breakdown
      doc.fontSize(16).text('Cases by Animal Type', 50, y);
      y += 25;
      rescuesByAnimalType.forEach(item => {
        doc.fontSize(11).text(`${item._id}: ${item.count} cases`, 70, y);
        y += 18;
      });
      y += 20;

      // AI Classification Stats
      if (aiClassificationStats.length > 0) {
        doc.fontSize(16).text('AI Classification Statistics', 50, y);
        y += 25;
        aiClassificationStats.forEach(item => {
          doc.fontSize(11).text(`${item._id}: ${item.count} classifications`, 70, y);
          y += 18;
        });
        y += 20;
      }

      // Recent Rescues
      if (y > 600) {
        doc.addPage();
        y = 50;
      }
      doc.fontSize(16).text('Recent Rescue Cases', 50, y);
      y += 25;
      
      recentRescues.forEach((rescue, index) => {
        if (y > 700) {
          doc.addPage();
          y = 50;
        }
        doc.fontSize(11)
          .text(`${index + 1}. ${rescue.title}`, 70, y)
          .text(`Status: ${rescue.status}`, 400, y);
        y += 15;
        doc.text(`Animal: ${rescue.animal?.type || 'Unknown'}`, 70, y)
          .text(`Date: ${new Date(rescue.createdAt).toLocaleDateString()}`, 400, y);
        y += 20;
      });

      doc.end();
    }

  } catch (error) {
    console.error('Admin overview export error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to export admin overview'
    });
  }
});

module.exports = router;
